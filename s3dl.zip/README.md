# s3dl

S3 file downloader with multi-environment, multi-service credential management and automatic file type detection.

## Features

- **Multi-environment configs** — prod, staging, dev, etc. with separate credentials
- **Multi-service support** — different buckets and keys per service within each environment, with env-level defaults as fallback
- **Auto file extension** — detects content type from S3 metadata and sets the correct file extension
- **Interactive setup** — guided wizard to configure environments, services, and credentials
- **Flexible auth** — static keys, AWS CLI profiles, or default credential chain per env/service
- **Streaming download** — progress bar with streaming I/O, no full-file buffering
- **Shell completions** — tab completion for bash, zsh, fish, powershell
- **Inline mode** — skip config entirely with `--ak`, `--sk`, `-b` flags

## Install

```bash
cargo install --path .
```

Or build from source:

```bash
git clone https://github.com/YOUR_USERNAME/s3dl.git
cd s3dl
cargo build --release
# binary at ./target/release/s3dl
```

## Quick Start

```bash
# 1. Run the interactive setup wizard
s3dl setup

# 2. Download a file
s3dl -e prod -s kyc -f "documents/report"

# 3. Enable tab completions (pick your shell)
s3dl completions zsh >> ~/.zshrc
s3dl completions bash >> ~/.bashrc
s3dl completions fish > ~/.config/fish/completions/s3dl.fish
```

## Usage

### Download

Download args work both directly and via the `get` subcommand:

```bash
# These are equivalent:
s3dl -e prod -s kyc -f "path/to/key"
s3dl get -e prod -s kyc -f "path/to/key"

# Service is optional (uses env defaults)
s3dl -e prod -f "path/to/key"

# Override output path
s3dl -e prod -s kyc -f "path/to/key" -o ~/Desktop
s3dl -e prod -s kyc -f "path/to/key" -o ~/Desktop/custom-name.pdf

# Skip config entirely with inline credentials
s3dl -f "path/to/key" --ak AKIAIOSFODNN7EXAMPLE --sk wJalrXUtn/... -b my-bucket

# Skip auto extension detection
s3dl -e prod -s kyc -f "data/export" --no-auto-ext

# Quiet mode (no progress bar, only errors)
s3dl -e prod -s kyc -f "data/export" -q
```

### Config Management

```bash
s3dl setup                    # Interactive first-time wizard
s3dl config list              # Show all environments and services
s3dl config edit              # Open config in $EDITOR
s3dl config path              # Print config file location
s3dl config add-env           # Add a new environment
s3dl config add-service       # Add a service to an environment
s3dl config remove-env        # Remove an environment
s3dl config remove-service    # Remove a service
```

## Configuration

Config lives at `~/.config/s3dl/config.toml` (permissions `600`).

### Structure

```toml
[defaults]
region = "us-east-1"
output_dir = "~/Downloads"

[env.prod]
bucket = "my-prod-default-bucket"    # default for all prod services
access_key = "AKIA..."              # default credentials for prod
secret_key = "..."
region = "ap-south-1"
output_dir = "~/work/prod-downloads" # optional per-env output dir

# Services inherit from their environment.
# Only specify fields you want to override.

[env.prod.services.kyc]
bucket = "kyc-specific-bucket"       # own bucket, inherits prod credentials

[env.prod.services.esign]
bucket = "esign-bucket"
access_key = "AKIA_ESIGN..."         # esign has its own keys
secret_key = "..."

[env.prod.services.uploads]
bucket = "uploads-bucket"
profile = "uploads-sso"              # uses an AWS CLI profile instead
output_dir = "~/work/uploads"        # downloads go here by default

[env.staging]
profile = "staging-sso"              # entire env uses a profile
bucket = "staging-bucket"

[env.staging.services.kyc]
bucket = "staging-kyc-bucket"        # inherits staging profile
```

### Resolution Order

For each field (bucket, credentials, region, output_dir):

1. **CLI flag** — always wins (`--ak`, `--sk`, `-b`, `-o`, `-r`)
2. **Service config** — `[env.NAME.services.SVC]`
3. **Environment config** — `[env.NAME]`
4. **Global defaults** — `[defaults]`
5. **Hardcoded fallback** — `us-east-1`, `~/Downloads`

For authentication specifically:

1. CLI `--access-key` + `--secret-key`
2. Service-level `access_key`/`secret_key` or `profile`
3. Environment-level `access_key`/`secret_key` or `profile`
4. AWS default chain (env vars, `~/.aws/credentials`, instance role)

### Auto Extension Detection

Before downloading, `s3dl` fetches the object's `Content-Type` via `HEAD` and maps it to a file extension:

| Content-Type | Extension |
|---|---|
| application/pdf | .pdf |
| application/json | .json |
| application/xml, text/xml | .xml |
| image/jpeg | .jpg |
| image/png | .png |
| text/csv | .csv |
| text/plain | .txt |
| application/zip | .zip |
| ... | ... |

If the file key already has the correct extension, it's left alone. Use `--no-auto-ext` to skip.

## Shell Completions

```bash
# Bash
s3dl completions bash >> ~/.bashrc

# Zsh
s3dl completions zsh >> ~/.zshrc

# Fish
s3dl completions fish > ~/.config/fish/completions/s3dl.fish

# PowerShell
s3dl completions powershell >> $PROFILE
```

## License

MIT
